import time  # Import the time module for time delays

# Define GPIO pin numbers
TRIG_PIN = 2  # GPIO pin number for the ultrasonic sensor's trigger
ECHO_PIN = 3  # GPIO pin number for the ultrasonic sensor's echo
PUMP_PIN = 4  # GPIO pin number for the water pump
LED_PIN = 5   # GPIO pin number for the LED

# Initialize components (virtual components for Wokwi)
ultrasonic_sensor = Ultrasonic(TRIG_PIN, ECHO_PIN)  # Create an ultrasonic sensor
pump = Motor(PUMP_PIN)  # Create a water pump
led = LED(LED_PIN)  # Create an LED

while True:
    # Measure distance
    distance = ultrasonic_sensor.distance_cm  # Measure distance in centimeters

    if distance > 200:  # Water level is above 200 cm
        # Make the LED blink
        led.blink(on_time=0.5, off_time=0.5)  # LED blinks with 0.5 seconds on and off time
        pump.on()  # Water pump is turned on
    else:
        # Water level is below 200 cm
        # Turn off the LED and the pump
        led.off()
        pump.off()

    # Introduce a small delay to control the loop rate
    time.sleep(0.1)  # Sleep for 0.1 seconds


